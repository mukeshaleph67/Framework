# PGFont

```
Platform : iOS
version : 0.0.1
```

## Usage

`PGFont.font` contains  typogrpahy  for uob design system. follow the steps below to use the font.

```
import Playground
apply the font shown as below here H1 font is set to label
textLabel?.font = UIFont.font(name: PGFontName.Body1) OR UIFont.font(name: PGFontStyle.regular, size: PGFontSize.medium)

```
